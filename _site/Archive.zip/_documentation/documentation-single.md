---
# Page settings
title: Documentation single # Define a title of your page
description: Documentation single — Description # Define a description of your page
keywords: # Define keywords for search engines
order: 0 # Define order of this page in list of all documentation documents
comments: false # Set to "true" in order to enable comments on this page. Make sure you properly setup "disqus_forum_shortname" variable in "_config.yml"

# Hero section
hero:
    title: Documentation single — Title
    text: Documentation single — Text
---

Add your markdown content here ...
