---
# Page settings
layout: documentation-archive # Choose layout: "default", "homepage" or "documentation-archive"
title: Publications # Define a title of your page
description: # Define a description of your page
keywords: # Define keywords for search engines

# Hero section
hero:
    title: Hero section — Title
    text: Hero section — Text
---
